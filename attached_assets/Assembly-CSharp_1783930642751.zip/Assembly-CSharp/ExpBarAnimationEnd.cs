public delegate void ExpBarAnimationEnd();
