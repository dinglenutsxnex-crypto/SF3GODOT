public class BoosterIntentModule : IntentModule
{
}
