public delegate void CardAnimationEnd();
