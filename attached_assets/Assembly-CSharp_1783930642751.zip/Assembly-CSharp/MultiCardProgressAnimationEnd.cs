public delegate void MultiCardProgressAnimationEnd();
